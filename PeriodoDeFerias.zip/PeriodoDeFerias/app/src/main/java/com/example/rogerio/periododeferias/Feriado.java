package com.example.rogerio.periododeferias;



/**
 * Created by Rogerio on 08/12/2015.
 */
public class Feriado {
    private String nome;
    private String data;
    private long id;


    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
}
