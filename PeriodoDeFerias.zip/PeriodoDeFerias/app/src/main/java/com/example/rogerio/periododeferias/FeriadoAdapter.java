package com.example.rogerio.periododeferias;

import java.util.List;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Rogerio on 08/12/2015.
 */
public class FeriadoAdapter extends BaseAdapter {
    private Context context;
    private List<Feriado> lista;

    public FeriadoAdapter(Context context, List<Feriado> lista){
        this.context = context;
        this.lista = lista;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return lista.size();
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        return lista.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        // TODO Auto-generated method stub
        return lista.get(arg0).getId();
    }

    @Override
    public View getView(int position, View arg1, ViewGroup arg2) {
        final int auxPosition = position;

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.activity_listagem_3, null);

        TextView tvNome = (TextView) layout.findViewById(R.id.txtNome);
        tvNome.setText(lista.get(position).getNome() + " - " + lista.get(position).getData());

//        TextView tvData = (TextView) layout.findViewById(R.id.txtData);
//        tvData.setText(lista.get(position).getData());

        Button editarBt = (Button) layout.findViewById(R.id.btnEditar);
        editarBt.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(context, NovoFeriadoActivity.class);
                intent.putExtra("nome", lista.get(auxPosition).getNome());
                intent.putExtra("data", lista.get(auxPosition).getData());
                intent.putExtra("id", lista.get(auxPosition).getId());
                context.startActivity(intent);
            }
        });

        Button deletarBt = (Button) layout.findViewById(R.id.btnDeletar);
        deletarBt.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View arg0) {

                DBAdapter objDBAdapter = new DBAdapter(context);
                objDBAdapter.open();
                objDBAdapter.deletarFeriado(lista.get(auxPosition).getId());
                objDBAdapter.close();

                Toast.makeText(context, "Feriado apagado com sucesso!", Toast.LENGTH_SHORT).show();
                layout.setVisibility(View.GONE);
            }
        });

        return layout;
    }
}
