package com.example.rogerio.periododeferias;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rogerio on 07/12/2015.
 */
public class DBAdapter {
    public static final String KEY_ROWID = "_id";
    public static final String KEY_NOME = "nome";
    public static final String KEY_DATA = "data";
    private static final String TAG = "DBAdapter";

    private static final String DATABASE_NAME = "FeriadosDB";
    private static final String DATABASE_TABLE = "feriados";
    private static final int DATABASE_VERSION = 6;

    private static final String DATABASE_CREATE =
            "create table feriados (_id integer primary key autoincrement, "
                    + "nome text not null, data text not null);";

    private final Context context;

    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    public DBAdapter(Context ctx)
    {
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper(Context context)
        {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            try {
                db.execSQL(DATABASE_CREATE);

                //insere os feriados nacionais 2016
                ContentValues initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Reveillon");
                initialValues.put(KEY_DATA, "01/01/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Paixão de Cristo");
                initialValues.put(KEY_DATA, "25/03/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Páscoa");
                initialValues.put(KEY_DATA, "27/03/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Tiradentes");
                initialValues.put(KEY_DATA, "21/04/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Dia do Trabalho");
                initialValues.put(KEY_DATA, "01/05/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Corpus Christi");
                initialValues.put(KEY_DATA, "26/05/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Indep. do Brasil");
                initialValues.put(KEY_DATA, "07/09/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Nossa Senhora");
                initialValues.put(KEY_DATA, "12/10/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Finados");
                initialValues.put(KEY_DATA, "02/11/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Proclamação da Repúb.");
                initialValues.put(KEY_DATA, "15/11/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

                initialValues = new ContentValues();
                initialValues.put(KEY_NOME, "Natal");
                initialValues.put(KEY_DATA, "25/12/2016");
                db.insert(DATABASE_TABLE, null, initialValues);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS feriados");
            onCreate(db);
        }
    }

    //---abre o banco---
    public DBAdapter open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }

    //---fecha o banco---
    public void close()
    {
        DBHelper.close();
    }

    //insere os feriados nacionais 2016
    public long inserirFeriadosNacionais(String nome, String data)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_NOME, nome);
        initialValues.put(KEY_DATA, data);
        return db.insert(DATABASE_TABLE, null, initialValues);
    }

    //---insere um feriado---
    public long inserirFeriado(Feriado feriado)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_NOME, feriado.getNome());
        initialValues.put(KEY_DATA, feriado.getData());
        return db.insert(DATABASE_TABLE, null, initialValues);
    }

    //---atualiza um feriado---
    public boolean atualizarFeriado(long rowId, String nome, String data)
    {
        ContentValues args = new ContentValues();
        args.put(KEY_NOME, nome);
        args.put(KEY_DATA, data);
        return db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null) > 0;
    }

    //---deleta um feriado---
    public boolean deletarFeriado(long rowId)
    {
        return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
    }

    //---busca todos os feriados---
    public List<Feriado> buscarTodosFeriados()
    {
        Cursor cursor = db.query(DATABASE_TABLE, new String[]{KEY_ROWID, KEY_NOME,
            KEY_DATA}, null, null, null, null, null);

        List<Feriado> lista = new ArrayList<Feriado>();
        //String[] colunas = new String[]{"_id", "nome", "data"};

        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();

            do {
                Feriado f = new Feriado();
                f.setId(cursor.getLong(0));
                f.setNome(cursor.getString(1));
                f.setData(cursor.getString(2));

                lista.add(f);
            } while (cursor.moveToNext());
        }

        return lista;
    }

    //---busca um feriado---
    public Cursor buscarFeriado(long rowId) throws SQLException
    {
        Cursor mCursor =
                db.query(true, DATABASE_TABLE, new String[] {KEY_ROWID,
                                KEY_NOME, KEY_DATA}, KEY_ROWID + "=" + rowId, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }
}
