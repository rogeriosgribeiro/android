package com.example.rogerio.periododeferias;

import android.text.format.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by Rogerio on 16/12/2015.
 */
public class Util {

    public String somaDataRetInString(String data, int somaDias)
    {
        String dataVerificada = converteDataBrasil(verificaMascaraData(data));

        int dia = Integer.parseInt(dataVerificada.substring(0, 2));
        int mes = Integer.parseInt(dataVerificada.substring(3, 5));
        int ano = Integer.parseInt(dataVerificada.substring(6, 10));

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        Calendar calendar = new GregorianCalendar(ano, mes, dia);
        Date dt = new Date();

        dt = convertDate(dataVerificada);
        calendar.setTime(dt);
        calendar.add(calendar.DATE, somaDias);

        return sdf.format(calendar.getTime());
    }

    public Date somaDataRetInDate(String data, int somaDias)
    {
        String dataVerificada = converteDataBrasil(verificaMascaraData(data));

        int dia = Integer.parseInt(dataVerificada.substring(0, 2));
        int mes = Integer.parseInt(dataVerificada.substring(3, 5));
        int ano = Integer.parseInt(dataVerificada.substring(6, 10));

        Calendar calendar = new GregorianCalendar(ano, mes, dia);
        Date dt = new Date();

        dt = convertDate(dataVerificada);
        calendar.setTime(dt);
        calendar.add(calendar.DATE, somaDias);

        return calendar.getTime();
    }

    public Integer diffDate(Date data_1, Date data_2)
    {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(data_1);

        Calendar calendar2 = new GregorianCalendar();
        calendar2.setTime(data_2);

        Date startDate = calendar.getTime();
        Date endDate = calendar2.getTime();

        int difference=
                ((int)((startDate.getTime()/(24*60*60*1000))
                        -(int)(endDate.getTime()/(24*60*60*1000))));

        return difference;
    }

    public static Date convertDate(String date) {
        // here date = gpsD+" "+gpsT;
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        Date destDate;
        try {

            return destDate = format.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String convertDateToString(String date, String dateFormate) {
        // here date = gpsD+" "+gpsT;
        SimpleDateFormat format = new SimpleDateFormat("ddMMyy HHmmss", Locale.getDefault());
        SimpleDateFormat destFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.getDefault());

        Date destDate;
        try {
            destDate = format.parse(date);
            return destFormat.format(destDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "";
    }

    public String converteDataBrasil(String data)
    {
        String dataConvertida = "";
        try
        {
            //SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyy/MM/dd");
            SimpleDateFormat ddMMyyyy = new SimpleDateFormat("dd/MM/yyyy");
            dataConvertida = ddMMyyyy.format(ddMMyyyy.parse(verificaMascaraData(data)));
        }
        catch(Exception e)
        {}

        return dataConvertida;
    }

    public String verificaMascaraData(String data)
    {
        for (int i = 0; i < data.length(); i++)
        {
            char c = data.charAt(i);
            if (c == '-')
                data = data.replace ('-', '/');
        }
        return data;
    }

    public String diasemana(Date data)
    {
        String weekDay;
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());

        String diasemana = dayFormat.format(data.getTime());

//        switch(diasemana) {
//            case"0": diasemana = "Sunday"; break;
//            case"1": diasemana = "Monday"; break;
//            case"2": diasemana = "Tuesday"; break;
//            case"3": diasemana = "Wednesday"; break;
//            case"4": diasemana = "Thursday"; break;
//            case"5": diasemana = "Friday"; break;
//            case"6": diasemana = "Saturday"; break;
//        }
        return diasemana;
    }
}
