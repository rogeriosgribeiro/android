package com.example.rogerio.periododeferias;

import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

/**
 * Created by Rogerio on 09/12/2015.
 */
public class ListaFeriadoActivity extends ListActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DBAdapter objDBAdapter = new DBAdapter(this.getBaseContext());
        objDBAdapter.open();
        List<Feriado> lista = objDBAdapter.buscarTodosFeriados();
        objDBAdapter.close();

        setListAdapter(new FeriadoAdapter(this, lista));
    }
}
