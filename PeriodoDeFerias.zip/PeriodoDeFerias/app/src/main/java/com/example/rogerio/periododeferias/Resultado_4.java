package com.example.rogerio.periododeferias;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.text.style.TtsSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Resultado_4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_4);

        Integer dias = 0;
        Intent it = getIntent();
        if (it != null)
        {
            Bundle params = it.getExtras();
            if (params != null)
            {
                //valor informado pelo usuário
                dias = Integer.parseInt(params.getString("dias"));
            }
        }

        //FAZ O CALCULO
        DBAdapter objDBAdapter = new DBAdapter(this.getBaseContext());
        objDBAdapter.open();
        List<Feriado> file = objDBAdapter.buscarTodosFeriados();
        objDBAdapter.close();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        List<String> feriados_envolvidos_ant = new ArrayList<String>();
        List<String> feriados_envolvidos_dps = new ArrayList<String>();
        List<String> maiores;
        Integer qtde_dias = 0;
        String tenta_fds_ant_feriado;
        String tenta_fds_dps_feriado;
        Date tenta_fds_ant;
        Date tenta_fds_dps;
        Date ant_feriado;
        Date prox_feriado;
        Integer maiores1 = 0;
        Integer maiores2 = 0;
        Integer maiores3 = 0;
        Integer menor = 0;
        Date dt_inicio;
        Date dt_final;
        HashMap<String,String> marcacoes = new HashMap<String, String>();

        Util objUtil = new Util();

        for (int v = 0; v < file.size(); v++)
        {
            //############################################################
            // ##### VERIFICA A QUANTIDADE DE DIAS ANTES DOS FERIADOS #####
            // ############################################################

            Date Inicio = null;
            Date Final = null;
            Date Data_int = null;
            Date Data_oficial_saida = null; // limpa as variaveis para as proximas datas
            int Data_oficial_saida_AUX = 0; // limpa as variaveis para as proximas datas

            if (feriados_envolvidos_ant.contains(file.get(v).getData()))
                continue; // verifica se o feriado ja foi envolvida em alguma conta anterior

            qtde_dias = dias + 1; // soma de quantidade de dias informadas + 1 do feriado

            // verifica os dias antes do feriado
            Data_int = objUtil.somaDataRetInDate(file.get(v).getData(), 0);
            //Data_int = dt(file.get(v).toString()); // data do feriado em numero
            Final = objUtil.somaDataRetInDate(file.get(v).getData(), 0);
            //Final = dt(file.get(v).toString()); // data do feriado em numero

            tenta_fds_ant_feriado =  objUtil.somaDataRetInString(file.get(v).getData(), -1);
            //tenta_fds_ant_feriado = dts(Data_int - 1); // verifica o dia da semana de 1 dia antes do feriado
            tenta_fds_dps_feriado = objUtil.somaDataRetInString(file.get(v).getData(), 1);
            //tenta_fds_dps_feriado = dts(Data_int + 1); // verifica o dia da semana de 1 dia depois do feriado

            // soma os dias de sabado e domingo depois do periodo
            if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_dps_feriado, 0)).equals("Sunday")) {
                qtde_dias += 1;
                Final = objUtil.somaDataRetInDate(sdf.format(Final), 1);
            } else if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_dps_feriado, 0)).equals("Saturday")) {
                qtde_dias += 2;
                Final = objUtil.somaDataRetInDate(sdf.format(Final), 2);
            }

            int AuxInicio = 0;
            // soma os dias de sabado e domingo antes do periodo
            if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_ant_feriado, 0)).equals("Sunday")) {
                qtde_dias += 2;
                AuxInicio = AuxInicio - 2;
                //Inicio = objUtil.somaDataRetInDate(sdf.format(Inicio), -2);
            } else if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_ant_feriado, 0)).equals("Saturday")) {
                qtde_dias += 1;
                AuxInicio = AuxInicio - 1;
                //Inicio = objUtil.somaDataRetInDate(sdf.format(Inicio), -1);
            }

            Inicio = objUtil.somaDataRetInDate(sdf.format(Data_int), AuxInicio - dias);

            tenta_fds_ant = objUtil.somaDataRetInDate(sdf.format(Inicio), -1);
            //tenta_fds_ant = dts(Inicio - 1); // verifica o dia da semana de 1 dia antes da data de inicio das ferias

            // soma os dias de sabado e domingo antes do inicio do periodo
            if (objUtil.diasemana(tenta_fds_ant).equals("Domingo")) {
                qtde_dias += 2;
                Inicio = objUtil.somaDataRetInDate(sdf.format(Inicio), -2);
                Data_oficial_saida_AUX = 2;
            } else if (objUtil.diasemana(tenta_fds_ant).equals("Sabado")) {
                qtde_dias += 1;
                Inicio = objUtil.somaDataRetInDate(sdf.format(Inicio), -1);
                Data_oficial_saida_AUX = 2;
            }

            if (Data_oficial_saida_AUX > 0)
                Data_oficial_saida = objUtil.somaDataRetInDate(sdf.format(Inicio), Data_oficial_saida_AUX);
            else
                Data_oficial_saida = objUtil.somaDataRetInDate(sdf.format(Inicio), 0);

            for (int i = 1; i <= 10; i++)
            {
                prox_feriado = objUtil.somaDataRetInDate(file.get(v + i).getData(), 0);
                if (prox_feriado != null)
                    break;
                else
                {
                    if (!prox_feriado.equals((objUtil.somaDataRetInDate(sdf.format(Final), 1))))
                        break;
                    else
                    {
                        Final = prox_feriado;
                        qtde_dias++;
                        if (objUtil.diasemana(objUtil.somaDataRetInDate(sdf.format(Final), 0)).equals("Sexta"));
                        {
                            qtde_dias += 2;
                            Final = objUtil.somaDataRetInDate(sdf.format(Final), 2);
                        }
                        feriados_envolvidos_ant.add(file.get(v + i).getData());
                    }
                }
            }

            // verifica os outros feriados para verificar se existe feriados anteriores
            Integer j = 0;
            for (int i = 10; i >= 1; i--)
            {
                j++;
                ant_feriado = objUtil.somaDataRetInDate(file.get(v - j).getData(), 0);
                if (ant_feriado != null)
                    break;
                else
                {
                    if (!ant_feriado.equals((objUtil.somaDataRetInDate(sdf.format(Inicio), -1))))
                        break;
                    else
                    {
                        Inicio = ant_feriado;
                        qtde_dias++;
                        if (objUtil.diasemana(objUtil.somaDataRetInDate(sdf.format(Inicio), 0)).equals("Segunda"));
                        {
                            qtde_dias += 2;
                            Inicio = objUtil.somaDataRetInDate(sdf.format(Inicio), -2);
                        }
                        feriados_envolvidos_ant.add(file.get(v - j).toString());
                    }
                }
            }

            dt_inicio = Inicio;
            dt_final = Final;

            marcacoes = new HashMap<String, String>();
            // Put data
            marcacoes.put("dt_inicio", dt_inicio.toString());
            marcacoes.put("dt_ini_semana", objUtil.diasemana(dt_inicio));
            marcacoes.put("dt_final", dt_final.toString());
            marcacoes.put("dt_fin_semana", objUtil.diasemana(dt_final));
            marcacoes.put("qtde_dias", qtde_dias.toString());
            marcacoes.put("dt_saida_oficial", sdf.format(Data_oficial_saida));
            marcacoes.put("dt_volta_oficial", sdf.format(objUtil.somaDataRetInDate(sdf.format(Final), 1)));

            // destaca os periodos com mais dias
            if (maiores1 > 0)
                maiores1 = qtde_dias;
            else if (maiores2 > 0)
                maiores2 = qtde_dias;
            else if (maiores3 > 0)
                maiores3 = qtde_dias;
            if (maiores1 <= maiores2 && maiores1 <= maiores3)
            {
                if (qtde_dias > maiores1)
                    maiores1 = qtde_dias;
            }
            else if (maiores2 <= maiores1 && maiores2 <= maiores3)
            {
                if (qtde_dias > maiores2)
                    maiores2 = qtde_dias;
            }
            else if (maiores3 <= maiores1 && maiores3 <= maiores2)
            {
                if (qtde_dias > maiores3)
                    maiores3 = qtde_dias;
            }

            //###########################################################
            //##### VERIFICA A QUANTIDADE DE DIAS APÓS DOS FERIADOS #####
            //###########################################################
            Inicio = null;
            Final = null;
            Data_int = null;
            qtde_dias = 0;
            Data_oficial_saida = null;
            Data_oficial_saida_AUX = 0; // limpa as variaveis para as proximas datas

            if (feriados_envolvidos_dps.contains(file.get(v).getData()))
                continue; // verifica se o feriado ja foi envolvida em alguma conta anterior

            qtde_dias = dias + 1; // soma de quantidade de dias informadas + 1 do feriado

            // verifica os dias antes do feriado
            Data_int = objUtil.somaDataRetInDate(file.get(v).getData(), 0);
            Inicio = objUtil.somaDataRetInDate(file.get(v).getData(), 0);

            tenta_fds_ant_feriado = objUtil.somaDataRetInString(sdf.format(Data_int), -1);
            tenta_fds_dps_feriado = objUtil.somaDataRetInString(sdf.format(Data_int), 1);

            // soma os dias de sabado e domingo depois do periodo
            if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_dps_feriado, 0)).equals("Sunday"))
            {
                qtde_dias += 1;
                Data_oficial_saida_AUX = 2;
                Final = objUtil.somaDataRetInDate(sdf.format(Final), 1);
            } else if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_dps_feriado, 0)).equals("Saturday"))
            {
                qtde_dias += 2;
                Data_oficial_saida_AUX = 2;
                Final = objUtil.somaDataRetInDate(sdf.format(Final), 2);
            }
            // soma os dias de sabado e domingo antes do periodo
            if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_ant_feriado, 0)).equals("Sunday"))
            {
                qtde_dias += 2;
            } else if (objUtil.diasemana(objUtil.somaDataRetInDate(tenta_fds_ant_feriado, 0)).equals("Saturday")) {
                qtde_dias += 1;
            }

            int diff = objUtil.diffDate(Data_int, objUtil.somaDataRetInDate(sdf.format(Final), dias));

            Final = objUtil.somaDataRetInDate(sdf.format(Data_int), diff); // data de inicio das ferias

            tenta_fds_dps = objUtil.somaDataRetInDate(sdf.format(Final), 1); // verifica o dia da semana de 1 dia depois da data de inicio das ferias

            // soma os dias de sabado e domingo antes do inicio do periodo
            if (objUtil.diasemana(tenta_fds_dps).equals("Sabado"))
            {
                qtde_dias += 2;
                Final = objUtil.somaDataRetInDate(sdf.format(Final), 2);
            } else if (objUtil.diasemana(tenta_fds_ant).equals("Domingo")) {
                qtde_dias += 1;
                Final = objUtil.somaDataRetInDate(sdf.format(Final), 1);
            }
            if (Data_oficial_saida != null) {

                diff = objUtil.diffDate(Data_oficial_saida, objUtil.somaDataRetInDate(sdf.format(Inicio), 1));

                Data_oficial_saida = objUtil.somaDataRetInDate(sdf.format(Data_oficial_saida), diff);
            }
            else
                Data_oficial_saida = objUtil.somaDataRetInDate(sdf.format(Inicio), 1);
            // verifica os outros feriados para verificar se existe feriados seguidos
            for (int i=1; i<=10; i++) {
                prox_feriado = objUtil.somaDataRetInDate(file.get(v + i).getData(), 0);
                if (prox_feriado != null)
                    break;
                else
                {
                    if (!prox_feriado.equals(objUtil.somaDataRetInDate(sdf.format(Final), 1)))
                        break;
                    else
                    {
                        Final = prox_feriado;
                        qtde_dias++;
                        if (objUtil.diasemana(Final).equals("Sexta"))
                        {
                            qtde_dias += 2;
                            Final = objUtil.somaDataRetInDate(sdf.format(Final), 2);
                        }
                        feriados_envolvidos_ant.add(file.get(v + i).toString());
                    }
                }
            }
            // verifica os outros feriados para verificar se existe feriados anteriores
            j = 0;
            for (int i=10; i>=1; i--) {
                j++;
                ant_feriado = objUtil.somaDataRetInDate(file.get(v - j).getData(), 0);
                if (ant_feriado != null)
                    break;
                else
                {
                    if (!ant_feriado.equals(objUtil.somaDataRetInDate(sdf.format(Inicio), -1)))
                        break;
                    else
                    {
                        Inicio = ant_feriado;
                        qtde_dias++;
                        if (objUtil.diasemana(Inicio).equals("Segunda"))
                        {
                            qtde_dias += 2;
                            Inicio = objUtil.somaDataRetInDate(sdf.format(Inicio), -2);
                        }
                        feriados_envolvidos_ant.add(file.get(v - j).toString());
                    }
                }
            }
            dt_inicio = Inicio;
            dt_final = Final;

            marcacoes = new HashMap<String, String>();
            // Put data
            marcacoes.put("dt_inicio", dt_inicio.toString());
            marcacoes.put("dt_ini_semana", objUtil.diasemana(dt_inicio));
            marcacoes.put("dt_final", dt_final.toString());
            marcacoes.put("dt_fin_semana", objUtil.diasemana(dt_final));
            marcacoes.put("qtde_dias", qtde_dias.toString());
            marcacoes.put("dt_saida_oficial", sdf.format(Data_oficial_saida));
            marcacoes.put("dt_volta_oficial", sdf.format(objUtil.somaDataRetInDate(sdf.format(Final), 1)));

            // destaca os periodos com mais dias
            if (maiores1 > 0)
                maiores1 = qtde_dias;
            else if (maiores2 > 0)
                maiores2 = qtde_dias;
            else if (maiores3 > 0)
                maiores3 = qtde_dias;
            if (maiores1 <= maiores2 && maiores1 <= maiores3)
            {
                if (qtde_dias > maiores1)
                    maiores1 = qtde_dias;
            }
            else if (maiores2 <= maiores1 && maiores2 <= maiores3)
            {
                if (qtde_dias > maiores2)
                    maiores2 = qtde_dias;
            }
            else if (maiores3 <= maiores1 && maiores3 <= maiores2)
            {
                if (qtde_dias > maiores3)
                    maiores3 = qtde_dias;
            }
        } // fim do for do file



        //ArrayList<String> teste = new ArrayList<String>();

        List<String> teste = new ArrayList<String>(marcacoes.values());

        ArrayAdapter<String> myAdapter=new
                ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1, teste);

        ListView myList = (ListView) findViewById(R.id.listView);
        myList.setAdapter(myAdapter);

//        Boolean primeiro = false;
//        if ((marcacoes != null) && (marcacoes.size() > 0))
//        {
//            for (String key: marcacoes.keySet())
//            {
//                TextView tvDataInicio = (TextView) findViewById(R.id.txtDataInicio);
//                tvDataInicio.setText(marcacoes.get("dt_inicio"));
//
//                if (Integer.parseInt(marcacoes.get("qtde_dias")) == maiores1 || Integer.parseInt(marcacoes.get("qtde_dias")) == maiores2 || Integer.parseInt(marcacoes.get("qtde_dias")) == maiores3) {
//                    //bgcolor = '#00FF00';
//
//                }
//                else
//                {
//                    //bgcolor = '#FFFFFF';
//                }
//
//                if (!primeiro)
//                {
//                    primeiro = true;
//                    echo "         <TR>\n";
//                    echo "            <TD BGCOLOR=\"#BBBBBB\" ALIGN=\"CENTER\" COLSPAN=5><B>".ano($v['dt_inicio'])."</B></TD>\n";
//                    echo "         </TR>\n";
//                }
//                else if (ano_ant != ano($v['dt_inicio']))
//                {
//                    echo "         <TR>\n";
//                    echo "            <TD BGCOLOR=\"#BBBBBB\" ALIGN=\"CENTER\" COLSPAN=5><B>".ano($v['dt_inicio'])."</B></TD>\n";
//                    echo "         </TR>\n";
//                }
//                ano_ant = ano($v['dt_inicio']);
//                echo "         <TR>\n";
//                echo "            <TD BGCOLOR=\"".$bgcolor."\" ALIGN=\"LEFT\">".$v['dt_inicio']." (".$v['dt_ini_semana'].")</TD>\n";
//                echo "            <TD BGCOLOR=\"".$bgcolor."\" ALIGN=\"LEFT\">".$v['dt_final']." (".$v['dt_fin_semana'].")</TD>\n";
//                echo "            <TD BGCOLOR=\"".$bgcolor."\" ALIGN=\"CENTER\">".$v['qtde_dias']."</TD>\n";
//                echo "            <TD BGCOLOR=\"".$bgcolor."\" ALIGN=\"LEFT\">".$v['dt_saida_oficial']."(".diasemana($v['dt_saida_oficial']).")</TD>\n";
//                echo "            <TD BGCOLOR=\"".$bgcolor."\" ALIGN=\"LEFT\">".$v['dt_volta_oficial']."(".diasemana($v['dt_volta_oficial']).")</TD>\n";
//                echo "         </TR>\n";
//
//            }
//            echo "      </TABLE>\n";
//        }
    }

    /*private long dt(String data)
    { // 008 // 021

        data = data.replace("-",""); // 002
        data = data.replace(".", ""); // 002
        data = data.replace("/", ""); // 002

        Integer dia  = Integer.parseInt(data.substring(0, 2));
        Integer mes  = Integer.parseInt(data.substring(2, 2));
        Integer ano  = Integer.parseInt(data.substring(4,4));

        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.set(ano + 1900, mes, dia);
        return cal.getTime().getTime();
    }*/

    /*private Date dts(long inteiros)
    { // 021
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.get((int)inteiros);
        return cal.getTime();
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_resultado_4, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
