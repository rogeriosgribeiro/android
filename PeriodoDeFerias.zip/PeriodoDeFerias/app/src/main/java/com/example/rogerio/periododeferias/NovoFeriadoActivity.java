package com.example.rogerio.periododeferias;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Rogerio on 08/12/2015.
 */
public class NovoFeriadoActivity extends Activity {

    private Feriado feriado = new Feriado();
    private EditText nomeEt;
    private EditText dataEt;
    private Button inserirBt;
    private Button editarBt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_2);

        nomeEt = (EditText) findViewById(R.id.txtNome);
        dataEt = (EditText) findViewById(R.id.txtData);
        inserirBt = (Button) findViewById(R.id.btnInserir);
        editarBt = (Button) findViewById(R.id.btnEditar);

        Intent intent = getIntent();
        if(intent != null){
            Bundle bundle = intent.getExtras();
            if(bundle != null){

                feriado.setId(bundle.getLong("id"));
                feriado.setNome(bundle.getString("nome"));
                feriado.setData(bundle.getString("data"));

                nomeEt.setText(feriado.getNome());
                dataEt.setText(feriado.getData());

                inserirBt.setVisibility(View.GONE);
                editarBt.setVisibility(View.VISIBLE);
            }
        }
    }

    public void inserirFeriado(View view){

        feriado.setNome(nomeEt.getText().toString());
        feriado.setData(dataEt.getText().toString());

        DBAdapter objDBAdapter = new DBAdapter(view.getContext());
        objDBAdapter.open();
        objDBAdapter.inserirFeriado(feriado);
        objDBAdapter.close();

        Toast.makeText(this, "Feriado inserido com sucesso!", Toast.LENGTH_SHORT).show();
    }

    public void editarFeriado(View view){

        DBAdapter objDBAdapter = new DBAdapter(view.getContext());
        objDBAdapter.open();
        objDBAdapter.atualizarFeriado(feriado.getId(), nomeEt.getText().toString(), dataEt.getText().toString());
        objDBAdapter.close();

        Toast.makeText(this, "Feriado \""+ feriado.getNome()+"\" atualizado com sucesso.", Toast.LENGTH_SHORT).show();
    }
}
